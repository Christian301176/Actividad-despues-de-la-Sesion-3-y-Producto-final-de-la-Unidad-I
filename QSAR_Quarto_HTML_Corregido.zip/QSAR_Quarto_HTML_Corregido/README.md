# Proyecto QSAR Fish Toxicity - Unidad I

1. Descomprima la carpeta completa en `D:/UPeU/Ciencia de Datos e IA Aplicada/`.
2. Abra **Reporte_Unidad_I_QSAR.qmd** en RStudio desde la carpeta descomprimida (NO desde el ZIP).
3. Verifique que Quarto esté instalado (`quarto --version`) y que R tenga `knitr` (`install.packages("knitr")` si falta).
4. Pulse **Render**. La salida de Quarto será `Reporte_Unidad_I_QSAR.html` en esta misma carpeta.
5. El archivo HTML incluido en la entrega es una **vista de referencia generada independientemente** con los datos y los análisis, no una renderización de Quarto-R verificada en esta máquina.

El CSV original está en `data/raw/qsar_fish_toxicity.csv`. La semilla madre es 2026. El código usa solo R base y knitr (que Quarto necesita para ejecutar R).
